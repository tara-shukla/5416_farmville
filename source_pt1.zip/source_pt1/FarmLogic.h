// MyClass.hpp
#pragma once    // or include guards


class FarmLogic {
public:
    static void start();
private:
    static void run();
};
